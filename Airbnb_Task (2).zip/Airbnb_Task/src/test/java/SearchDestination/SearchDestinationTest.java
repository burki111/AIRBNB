package SearchDestination;

import AirbnbBaseClassTest.BaseClassTest;
import Pages.ExtentManager;
import Pages.JSon_Format;
import Pages.SearchPage;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


public class SearchDestinationTest extends BaseClassTest {
    @Test(priority = 1)
    public void searchDestination() {
        //SearchDestinationTest search = new SearchDestinationTest();
       // search.searchPage.enterDestination("Tirana");
       /*
        //SearchPage searchPage = new SearchPage(driver);
        // Log the start of the test
        startTest("Search Destination");


       // test = extent.createTest("Search Destination");
        childTest = test.createNode("Click on Search destination Box");

        try {
            searchPage.waitForPageToLoad();
            childTest.pass("Clicked on Search destination box successfully.");
        } catch (Exception e) {
            childTest.fail("Failed to click search destination box: " + e.getMessage());
        }

        childTest = test.createNode("Enter City Destination");
        try {
            searchPage.enterDestination("Tirana");
            childTest.pass("Entered destination: Tirana");
        } catch (Exception e) {
            childTest.fail("Failed to enter destination: " + e.getMessage());
        }
        System.out.println("1. Search for the City Tirana, Albania completed.");
    }

    //This method only for making an extent report without child
    //searchPage.waitForPageToLoad();
    //searchPage.enterDestination("Tirana");
    //test.info("Entered destination as 'Tirana'.");
    // System.out.println("1. Search for the City Tirana, Albania completed.");

   */
        //SoftAssert softassert = new SoftAssert();
        ExtentManager.startParentTest("Search Test");

        try {
            ExtentManager.startChildTest("Check whether the search tab is clickable for Search City Destination");
            try {
                ExtentManager.startGrandChildTest("Waiting for the page to load to enter the city name.");
                searchPage.waitForPageToLoad();
                ExtentManager.logPass("Page loaded Successfully.");
            } catch (Exception e) {
                ExtentManager.logFail("Failed to load the page: " + e.getMessage());
            } finally {
                ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
            }
            try {
                String destination = "Tirana";
                ExtentManager.startGrandChildTest("Testing the input name for Type City Destination");
                searchPage.enterDestination(destination);
                ExtentManager.logInfo("Verification Search Operation for City.!");
                Assert.assertEquals(destination, "Tirana","City name matched.");
                //softassert.assertEquals(false, true, "Not correct Destination added");
                ExtentManager.logPass(" Entered destination Successfully.!"+destination);
                //softassert.assertAll();
                System.out.println("1. City Entered Successfully!");
                //ExtentManager.endGrandChildTest();
            } catch (Exception e) {
                ExtentManager.logFail("Failed to enter or find destination: " + e.getMessage());
            } finally {
                ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
            }
            ExtentManager.logPass("Search City Destination Operation passed Successfully");
            //ExtentManager.endChildTest();
        } catch (Exception e) {
            ExtentManager.logFail("Search Operation failed: " + e.getMessage());
        } finally {
            ExtentManager.endChildTest(); // Ensure grandchild test ends
        }

    }
}
