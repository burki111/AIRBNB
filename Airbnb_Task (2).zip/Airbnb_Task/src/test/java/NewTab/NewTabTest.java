package NewTab;

import AirbnbBaseClassTest.BaseClassTest;
import Pages.BookingPageNextTab;

import org.testng.annotations.Test;

public class NewTabTest extends BaseClassTest {

    @Test
    public void NextTab(){
        //BookingPageNextTab newtab = new BookingPageNextTab(driver);
        //startTest("Close Pop-up status");

    // Step 5: Close the pop-up
        newtab.closePopUp();
      //  test.info("Pop-up Closed Successfully'.");
        System.out.println("6. Popup done! .");
       // file.creatingFile();

     }

}
