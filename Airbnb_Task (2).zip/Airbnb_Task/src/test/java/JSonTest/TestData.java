package JSonTest;

import AirbnbBaseClassTest.BaseClassTest;
import org.openqa.selenium.WebDriver;

public class TestData extends BaseClassTest {
    // For WebDriver integration
    public static WebDriver driver;
    private String destination;
    private String checkInDate;
    private String checkOutDate;
    private int guests;

    // Getters and setters
    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(String checkInDate) {
        this.checkInDate = checkInDate;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public int getGuests() {
        return guests;
    }

    public void setGuests(int guests) {
        this.guests = guests;
    }
}

