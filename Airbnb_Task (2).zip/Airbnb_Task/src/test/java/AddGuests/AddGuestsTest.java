package AddGuests;

import AirbnbBaseClassTest.BaseClassTest;
import Pages.AddGuestsPage;
import Pages.ExtentManager;
import org.testng.annotations.Test;

public class AddGuestsTest extends BaseClassTest {
    @Test(priority = 4)
    public void addGuests() {
//        AddGuestsPage addGuestsPage = new AddGuestsPage(driver);
        // startTest("Add Guests list");
        // addGuestsPage.addGuests();
        //  test.info("Guests list added successfully.");
        //startTest("Click Search button");
        //  addGuestsPage.clicksearchbarbutton();
        //test.info("Search successfull");
        //System.out.println("4. Add Guests");

/*
        startTest("Add Guests List"); //Parent Test

        //Creating the first child test
        childTest = test.createNode("Clicking on the Guests bar.");
        try{ //Creating the grandchild for the first child
            grandChildTest = childTest.createNode("Locating the path for Guest element");
            addGuestsPage.addGuests();
            grandChildTest.pass("Guest Element located and interacted with successfully!.");
            childTest.pass("Guest bar button clicked successfully!.");
        }catch (Exception e) {
            childTest.fail("Failed to click on the guest bar button: " + e.getMessage());
        }
        //Creating the second child test
        childTest = test.createNode("Selecting from the Guests options list");
        try { //Creating the grandchild for the second child
            grandChildTest = childTest.createNode("Opening the guest list options to select no.of guests.");
            addGuestsPage.selectNoOfGuests();
            grandChildTest.pass("Guest list opened and selected no.of guests successfully!.");
            childTest.pass("Guest list added Successfully!.");
        }catch (Exception e) {
            childTest.fail("Failed to add guests: " + e.getMessage());
    }
        //Creating the third child test
        childTest = test.createNode("Clicking the search bar button");
        try{
            addGuestsPage.clicksearchbarbutton();
            childTest.pass("Operation Successfull!");
        }catch (Exception e) {
            childTest.fail("Operation search Unsuccessfull");

        }
    }
    */
        ExtentManager.startParentTest("Adding Guests.");
        try { //FIRST CHILD
            ExtentManager.startChildTest("Verification to check whether the test clicks on the guests bar and displays the Guests list category.");
            ExtentManager.logInfo("Test case about the click on the Guests bar and the Guests list category display.");
            addGuestsPage.ClickaddGuestslist();
            try {

                ExtentManager.startGrandChildTest("Select No. of Guests from the category and check whether the adding button for the guests works.");
                ExtentManager.logInfo("Guests selection Verification.");
                addGuestsPage.selectNoOfGuests();
                ExtentManager.logPass("No. of Guests list selected successfully.");
               // ExtentManager.endGrandChildTest();
            } catch (Exception e) {
                ExtentManager.logFail("Failed to add guests: " + e.getMessage());
            } finally {
            ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
        }

            ExtentManager.logPass("Guests bar found Successfully.!");
           // ExtentManager.endChildTest();
        }catch (Exception e) {
            ExtentManager.logFail("Failed to find and display Guests bar search: " + e.getMessage());
        }finally {
        ExtentManager.endChildTest(); // Ensure grandchild test ends
    }
//SECOND CHILD
        try {
            ExtentManager.startChildTest("Clicking the search bar button");
            addGuestsPage.clicksearchbarbutton();
            ExtentManager.logInfo("Search bar Operation Verification!");
            ExtentManager.logPass("Search bar Operation Passed!");
        } catch (Exception e) {
            ExtentManager.logFail("Operation search Unsuccessfull.");
        }finally {
            ExtentManager.endChildTest(); // Ensure grandchild test ends
        }
    }
}
