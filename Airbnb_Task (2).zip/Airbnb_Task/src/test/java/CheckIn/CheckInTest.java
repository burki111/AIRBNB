package CheckIn;

import AirbnbBaseClassTest.BaseClassTest;
import Pages.ExtentManager;
import Pages.CheckInPage;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;
public class CheckInTest extends BaseClassTest {
    @Test(priority = 2)
    public void checkIn() {

        //CheckInPage checkInPage = new CheckInPage(driver);
        //This method used only if no child is involved
        //startTest("Check in Status");
        //checkInPage.selectCheckInDay();
        // test.info("Check-in day selected successfully.");
        //System.out.println("2. Check in");

/*     This code is used only if it is a parent-child relationship not involving grand child.....

        startTest("Check in Status"); //Parent test

        childTest = test.createNode("Clicking on the Check in bar"); //First child test
        try {
            checkInPage.clickOnCheckinBar();
            childTest.pass("Check-In button clicked successfully.");
        } catch (Exception e) {
            childTest.fail("Failed to click Check-In button: " + e.getMessage());
        }
        childTest = test.createNode("Select Check-In Day Date");
        try {
            checkInPage.selectCheckInDay();
            childTest.pass("Check-In day Date selected successfully.");
        } catch (Exception e) {
            childTest.fail("Failed to select Check-In day: " + e.getMessage());
        }
    }*/

//The following code is implemented if it involves parent-child-grandchild....

/*
        startTest("Check in Status");

        // Create the first child test
        childTest = test.createNode("Clicking on the Check in bar");
        try {
            // Create a grandchild node for additional steps/details
            grandChildTest = childTest.createNode("Locating the Check-In bar element");
            checkInPage.clickOnCheckinBar();
            grandChildTest.pass("Element located and interacted with successfully.");

            grandChildTest = childTest.createNode("Verifying interaction with the Check-In bar");
            grandChildTest.pass("Interaction verified successfully.");

            childTest.pass("Check-In button clicked successfully.");
        } catch (Exception e) {
            childTest.fail("Failed to click Check-In button: " + e.getMessage());
        }

        // Create the second child test
        childTest = test.createNode("Select Check-In Day Date");
        try {
            // Create a grandchild node for finer details
            grandChildTest = childTest.createNode("Opening the calendar to select a date");
            checkInPage.selectCheckInDay();
            grandChildTest.pass("Calendar opened and date selected successfully.");

            grandChildTest = childTest.createNode("Validating the selected date");
            grandChildTest.pass("Selected date validated successfully.");

            childTest.pass("Check-In day date selected successfully.");
        } catch (Exception e) {
            childTest.fail("Failed to select Check-In day: " + e.getMessage());
        }
*/

        //SoftAssert softassert = new SoftAssert();
        ExtentManager.startParentTest("Searching for Check in Date");
        try {
            //ExtentManager.startChildTest("Verifying whether the Check-In bar displays the calender for selecting a date.");
            ExtentManager.startChildTest("Verifying whether the test is able to find and click on the check in bar.");
            checkInPage.clickOnCheckinBar();
           // Assert.assertTrue(false, "Failed to click on the check in bar.");
            try {
                ExtentManager.startGrandChildTest("Verifying whether the Check-In bar displays the calender for selecting a date.");
                //checkInPage.selectCheckInDay();
                ExtentManager.logInfo("Check in Date Verification.");

                ExtentManager.logPass("Check-in date calender displayed successfully.");
                System.out.println("2. Check in Date Passed!");
                //ExtentManager.endGrandChildTest();
            } catch (Exception e) {
                ExtentManager.logFail("Failed to get the display calender in Check-In date: " + e.getMessage());
                throw e;
            }finally {
                ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
            }
            try {
                ExtentManager.startGrandChildTest("Verifying whether the test is able to Select Check-In Date from the calender.");
                checkInPage.selectCheckInDay();
                //ExtentManager.logInfo("Check in Date Verification.");
                ExtentManager.logPass("Check-In date selected successfully.");
                //System.out.println("2. Check in Date Passed!");
                //ExtentManager.endGrandChildTest();
            } catch (Exception e) {
                ExtentManager.logFail("Failed to select Check-In date: " + e.getMessage());
                throw e;
            }finally {
                ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
            }
            ExtentManager.logPass("Check in date bar found and able to get clicked Successfully.");
            //ExtentManager.endChildTest();
        }catch (Exception e) {
            ExtentManager.logFail("Failed to find the Check-In date bar and get clicked. " + e.getMessage());
            throw e;
        }finally {
            ExtentManager.endChildTest(); // Ensure child test ends
        }

    }
}

