package SelectApartment;

import AirbnbBaseClassTest.BaseClassTest;
import Pages.ExtentManager;
import org.testng.annotations.Test;
import Pages.ApartmentPage;
import Pages.BookingPageNextTab;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class SelectApartmentTest extends BaseClassTest {
    @Test(priority = 5)
    public void SelectApartment() {
        //ApartmentPage select = new ApartmentPage(driver);
        // startTest("Select Apartment");
        ExtentManager.startParentTest("Apartment Selection");

        try {
            ExtentManager.startChildTest("Waiting for Apartment Page List to be Loaded.");
            try {
                ExtentManager.startGrandChildTest("Verifying if the first apartment in the list could be Selected.");
                select.clickselectApartment();
                ExtentManager.logInfo("Verification for Apartment Page Selection.!");
                ExtentManager.logPass("Apartment was selected Successfully.!");
                ExtentManager.endGrandChildTest();
            } catch (Exception e) {
                ExtentManager.logFail("Failed to select the first apartment in the list: " + e.getMessage());
            }finally {
                ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
            }
            ExtentManager.logPass("Apartment page loaded Successfully.");
             //ExtentManager.endChildTest();
        } catch (Exception e) {
            ExtentManager.logFail("Pages loading failed. " + e.getMessage());
        }finally {
            ExtentManager.endChildTest(); // Ensure grandchild test ends
        }

        try {
            ExtentManager.startChildTest("Waiting for the selected apartment to switch to new tab.");
            try {
                ExtentManager.startGrandChildTest("Waiting for the new tab to be loaded to view the apartment description.");
                select.switchToNewTab();
                ExtentManager.logInfo("Switch tab Operation Verification.!");
                ExtentManager.logPass("Selected Apartment page and description loaded Successfully.!");
                System.out.println("5. Apartment Selection!");
            } catch (Exception e) {
                ExtentManager.logFail("Apartment loading failed.");
            }finally {
                ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
            }
            ExtentManager.logPass("New tab switching for selected apartment Passed.");
        } catch (Exception e) {
            ExtentManager.logFail("New tab loading failed. " + e.getMessage());

        }finally {
            ExtentManager.endChildTest(); // Ensure grandchild test ends
        }

    }
}

        //select.clickselectApartment();
        //select.switchToNewTab();
       // test.info("Apartment selected successfully.");




