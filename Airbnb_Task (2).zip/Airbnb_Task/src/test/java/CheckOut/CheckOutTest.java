package CheckOut;

import AirbnbBaseClassTest.BaseClassTest;
import Pages.CheckOutPage;
import Pages.ExtentManager;
import org.testng.annotations.Test;

public class CheckOutTest extends BaseClassTest {
    @Test(priority = 3)
    public void checkOut() {
        //CheckOutPage checkOutPage = new CheckOutPage(driver);
        // startTest("Check out status");
        // checkOutPage.selectCheckOutDay();
        //test.info("Check-out day selected successfully.");
        //System.out.println("3. Check Out");
/*
        startTest("Check out Status");
        childTest = test.createNode("Selecting date for the Check out day");
        try {
            checkOutPage.selectCheckOutDay();
            childTest.pass("Check-out date clicked successfully.");
        } catch (Exception e) {
            childTest.fail("Failed to select Check-out day: " + e.getMessage());
        }

        // childTest = test.createNode("Select Check-In Day Date");
        // try {
        //  checkInPage.selectCheckInDay();
        // childTest.pass("Check-In day Date selected successfully.");
        //  } catch (Exception e) {
        // childTest.fail("Failed to select Check-In day: " + e.getMessage());
    }

 */


        ExtentManager.startParentTest("Search Check OUT date");
        try{
        ExtentManager.startChildTest("Verifying if Check-Out date bar can be clicked.");
            try {
                ExtentManager.startGrandChildTest("Verifying whether the Check-out bar displays the calender for selecting a date.");
               // checkInPage.selectCheckInDay();
                ExtentManager.logInfo("Check Out Date Verification.");
                ExtentManager.logPass("Check-out date calender displayed successfully.");
                System.out.println("3. Check out Date Passed!");
                //ExtentManager.endGrandChildTest();
            } catch (Exception e) {
                ExtentManager.logFail("Failed to get the display calender in Check-Out date: " + e.getMessage());
                throw e;
            }finally {
                ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
            }
        try {
            ExtentManager.startGrandChildTest("Select Check-out Date from Calender.");
            checkOutPage.selectCheckOutDay();
            ExtentManager.logPass("Check-out date selected from calender successfully.");
        } catch (Exception e) {
            ExtentManager.logFail("Failed to select the correct Check-out date: " + e.getMessage());
        }finally {
            ExtentManager.endGrandChildTest(); // Ensure grandchild test ends
        }
        ExtentManager.logPass("Check Out Date bar found and clicked Successfully.!");
        } catch (Exception e) {
            ExtentManager.logFail("Failed to click and find on the Check-out bar: " + e.getMessage());
            throw e;
        }finally {
            ExtentManager.endChildTest(); // Ensure grandchild test ends
        }

    }

    }

