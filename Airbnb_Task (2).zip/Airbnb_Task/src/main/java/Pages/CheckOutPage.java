package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CheckOutPage {
    protected static WebDriver driver;
    private final By checkOutDay = By.xpath("/html/body/div[5]/div/div/div[1]/div/div[3]/div[2]/div/div/div/header/div/div[2]/div[2]/div/div/div/form/div[2]/div/div[3]/div[2]/div/div/div/div/div/div/div/div[2]/div[1]/div/div[1]/div[4]/div/div/div[2]/button[37]");

    public CheckOutPage(WebDriver driver) {
        CheckOutPage.driver = driver;
    }

    public void selectCheckOutDay() {
        WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait3.until(ExpectedConditions.elementToBeClickable(checkOutDay));
        driver.findElement(checkOutDay).click();
    }
}

