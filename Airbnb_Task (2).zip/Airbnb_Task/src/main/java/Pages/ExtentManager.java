package Pages;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Base64;


public class ExtentManager {
    public static WebDriver driver;
    private static ExtentReports extent;
    private static ExtentTest parentTest;
    private static ExtentTest childTest;
    private static ExtentTest grandChildTest;
    private static Email email;
    public static class ScreenshotData {
        private final String filePath;
        private String image64;

        // Constructor
        public ScreenshotData(String filePath, String image64) {
            this.filePath = filePath;
            this.image64 = image64;
        }

        // Getters
        public String getFilePath() {
            return filePath;
        }

        public String getImage64() {
            return image64;
        }
    }
    public static ScreenshotData takeScreenshot(String fileName) {
        try {
            File file = (((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE));
            String filePath = System.getProperty("user.dir" ) + "/screenshots" + fileName + ".png";
            File outputFile = new File(filePath);

            FileUtils.copyFile(file, outputFile);
            // BufferedImage image = ImageIO.read(file);
            //BufferedImage compressedImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
            System.out.printf("\nScreenshot path: " + filePath);
            //ImageIO.write(compressedImage,"png", outputFile);
            //  FileInputStream inputStream = new FileInputStream(outputFile);
            byte[] imageBytes = Files.readAllBytes(outputFile.toPath());
            String Image64 = "data:image/png;base64," + Base64.getEncoder().encodeToString(imageBytes);
            //System.out.printf("\nScreenshot path: " + filePath);

            //return filePath;
            // return Image64;
            return new ScreenshotData(filePath, Image64);
        } catch (IOException e) {
            throw new RuntimeException("Error while capturing or saving screenshot: " + e.getMessage());
        }
    }



    // Initialize ExtentReports
    public static void initReports(WebDriver driver, String reportPath) {
        ExtentManager.driver = driver;
        email = new Email(driver);
        try {
            ExtentSparkReporter htmlReporter = new ExtentSparkReporter(reportPath);
            htmlReporter.config().setTheme(Theme.DARK);
            htmlReporter.config().setDocumentTitle("Airbnb Test Report");
            htmlReporter.config().setReportName("Test Execution Report");
            htmlReporter.config().thumbnailForBase64(true);

            extent = new ExtentReports();
            extent.attachReporter(htmlReporter);
            extent.setSystemInfo("OS", System.getProperty("os.name"));// I used method this for systeminfo
            extent.setSystemInfo("Browser", "Chrome");

            System.out.println("Extent Reports initialized.");
        } catch (Exception e) {
            System.out.println("Failed to initialize Extent Reports: " + e.getMessage());
        }
    }

    public static void startParentTest(String testName) {
        parentTest = extent.createTest(testName).assignDevice("Lenovo Core i7");
        childTest = null;
        grandChildTest = null;
    }

    public static void startChildTest(String testName) {
        if (parentTest != null) {
            childTest = parentTest.createNode(testName).assignCategory(parentTest.getModel().getName());
            grandChildTest = null;
        }
    }

    public static void startGrandChildTest(String testName) {
        if (childTest != null) {
            grandChildTest = childTest.createNode(testName).assignCategory(parentTest.getModel().getName());
        }
    }

    public static void logInfo(String message) {
        if (grandChildTest != null) {
            grandChildTest.info(message);
        } else if (childTest != null) {
            childTest.info(message);
        } else if (parentTest != null) {
            parentTest.info(message);
        }
    }

    public static void logPass(String message) {
        if (grandChildTest != null) {
            grandChildTest.pass(message);

        } else if (childTest != null) {
            childTest.pass(message);

        } else if (parentTest != null) {
            parentTest.pass(message);
        }

    }

    public static void logFail(String message) {
        ScreenshotData screenshot = takeScreenshot("failed_test_screenshot");
        if (grandChildTest != null) {
            grandChildTest.fail(message,MediaEntityBuilder.createScreenCaptureFromBase64String(screenshot.getImage64(), "screenshot").build());

        } else if (childTest != null) {
            childTest.fail(message,MediaEntityBuilder.createScreenCaptureFromBase64String(screenshot.getImage64(), "screenshot").build());

        } else if (parentTest != null) {
            parentTest.fail(message,MediaEntityBuilder.createScreenCaptureFromBase64String(screenshot.getImage64(), "screenshot").build());
        }

    }

    public static void logSkip(String message) {
        if (grandChildTest != null) {
            grandChildTest.fail(message);
        } else if (childTest != null) {
            childTest.fail(message);
        } else if (parentTest != null) {
            parentTest.fail(message);
        }

    }

    public static void endGrandChildTest() {
        grandChildTest = null; // Clear grandchild context
    }

    public static void endChildTest() {
        childTest = null; // Clear child context
    }


    public static String sendreportemail() {
        email = new Email(driver);


        String reportPath =  System.getProperty("user.dir")+ "/test-output/ExtentReport.html";
        System.out.printf("\nReportPath found at: " + reportPath);
        File reportFile = new File(reportPath);
        if (!reportFile.exists()) {
            System.err.println("Report file not found: " + reportFile);
        }else
            System.out.printf("\nReport Filepath: " + reportFile);
        try {
            Email.sendEmailWithExtentReport(
                    "smtp.gmail.com", "587", "burki.bayazid@gmail.com", "otbu vwep nhav xwzv",
                    "bayazidburki.trillium@gmail.com", "Test Execution Report",
                    "Please find the attached report and screenshot for the test.",
                    reportPath
            );
        } catch (Exception e) {
            System.out.println("Failed to send email: " + e.getMessage());
        }
        return reportPath;
    }
    public static void flushReport() {
        if (extent != null) {
            extent.flush();
            System.out.println("Report Flushed");


        }
    }
    }

/*
    // Start Parent Test
    public static void startParentTest(String testName) {
        try {
            parentTest = extent.createTest(testName).assignDevice("Project");
            childTest = null;
            grandChildTest = null;
        } catch (Exception e) {
            System.out.println("Failed to create Parent Test: " + e.getMessage());
        }
    }

    // Start Child Test
    public static void startChildTest(String testName) {
        try {
            if (parentTest != null) {
                childTest = parentTest.createNode(testName).assignCategory("Child");
                grandChildTest = null;
            } else {
                System.out.println("Parent test not initialized. Cannot create Child Test.");
            }
        } catch (Exception e) {
            System.out.println("Failed to create Child Test: " + e.getMessage());
        }
    }

    // Start Grand Child Test
    public static void startGrandChildTest(String testName) {
        try {
            if (childTest != null) {
                grandChildTest = childTest.createNode(testName).assignCategory("Grandchild");
            } else {
                System.out.println("Child test not initialized. Cannot create Grand Child Test.");
            }
        } catch (Exception e) {
            System.out.println("Failed to create Grand Child Test: " + e.getMessage());
        }
    }
//ANOTHER METHOD FOR LOG EVENTS
 public static void logInfo(String message) {
        if (grandChildTest == null) {
            System.out.println("Cannot log info. Grandchild test is not initialized.");
            return;
        }
        try {
            grandChildTest.info(message);
        } catch (Exception e) {
            System.out.println("Error logging info: " + e.getMessage());
        }
    }

    public static void logPass(String message) {
        if (grandChildTest == null) {
            System.out.println("Cannot log pass. Grandchild test is not initialized.");
            return;
        }
        try {
            grandChildTest.pass(message);
        } catch (Exception e) {
            System.out.println("Error logging pass: " + e.getMessage());
        }
    }

    public static void logFail(String message) {
        if (grandChildTest == null) {
            System.out.println("Cannot log fail. Grandchild test is not initialized.");
            return;
        }
        try {
            grandChildTest.fail(message);
        } catch (Exception e) {
            System.out.println("Error logging fail: " + e.getMessage());
        }
    }

    public static void logSkip(String message) {
        if (grandChildTest == null) {
            System.out.println("Cannot log skip. Grandchild test is not initialized.");
            return;
        }
        try {
            grandChildTest.skip(message);
        } catch (Exception e) {
            System.out.println("Error logging skip: " + e.getMessage());
        }
    }


    // End Grandchild Test
    public static void endGrandChildTest() {
        try {
            grandChildTest = null; // Explicitly clear grandchild context
        } catch (Exception e) {
            System.out.println("Failed to end Grandchild Test: " + e.getMessage());
       }
    }

    // End Child Test
   public static void endChildTest() {
       try {
           childTest = null; // Explicitly clear child context
        } catch (Exception e) {
            System.out.println("Failed to end Child Test: " + e.getMessage());
        }
    }

    // End Test and Flush Report
    public static void flushReport() {
        try {
            if (extent != null) {
                extent.flush();
            }
        } catch (Exception e) {
            System.out.println("Failed to flush Extent Reports: " + e.getMessage());
        }
    }

 */


