package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;

import static java.lang.System.out;

public class CreateFile
{
    private static String filepath;
    public static WebDriver driver;

    public CreateFile(String filepath)
    {
        this.filepath = filepath;

    }

    public CreateFile(WebDriver driver)
    {
        this.driver = driver;
    }

    public void creatingFile()
    {
        try
        {
            File file = new File(filepath);
            file.createNewFile();
            out.println("New file created: " + file.getName());
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

    public void writeData()
    {
//        WebElement info = driver.findElement(By.className("_t0tx82"));
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(filepath, true)))
        {
            By name = By.xpath("//div[@class='_t0tx82']//h1");
            By rnt = By.cssSelector("[data-plugin-in-point-id='BOOK_IT_SIDEBAR']");
            By desc = By.cssSelector("section div.o1kjrihn");
            By p1 = By.cssSelector("[data-plugin-in-point-id='HOST_OVERVIEW_DEFAULT']");
            By misc = By.cssSelector("[data-plugin-in-point-id='HIGHLIGHTS_DEFAULT']");
            By disc = By.cssSelector("[data-plugin-in-point-id='DESCRIPTION_DEFAULT']");
            By amn = By.cssSelector("[data-plugin-in-point-id='AMENITIES_DEFAULT']");
//            WebElement nameElement = driver.findElement(By.xpath("//div[@class='_t0tx82']//h1"));
//            String placeName = nameElement.getText();
            String placeName = getWebElementText(name);
            String rent = getWebElementText(rnt);
            String description = getWebElementText(desc);

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0, 500);");

            try
            {
                Thread.sleep(500);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }

            waitingtobevisible(p1);
            String heading = getWebElementText(p1);
            waitingtobevisible(misc);
            String highlights = getWebElementText(misc);
            waitingtobevisible(disc);
            String dftdecsription = getWebElementText(disc);
            waitingtobevisible(amn);
            String amenities = getWebElementText(amn);

//            writer.write("Place Name: " + placeName);
//            writer.newLine();
//            writer.write("Rent: " + rent);
//            writer.newLine();
//            writer.write("Description: " + description);
//            writer.newLine();
//            writer.newLine();



            StringBuilder sb = new StringBuilder();
            sb.append("Place Name: ").append(placeName).append("\n").append("Original Rent: ").append(rent)
                    .append("\n").append("Description: ").append(description).append("\n").append(heading).append("\n")
                    .append(highlights).append("\n").append(dftdecsription).append("\n").append(amenities).append("\n");

            writer.write(sb.toString());

//            System.out.println("Data written: " + placeName + ", " + rent + ", " + description);
            out.println("Data written: " + sb);

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }


    public static WebElement getWebElement(By by)
    {
        return driver.findElement(by);

    }

    public static String getWebElementText(By by)
    {
        return getWebElement(by).getText();

    }

    public static void waitingtobevisible(By by)
    {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }


}