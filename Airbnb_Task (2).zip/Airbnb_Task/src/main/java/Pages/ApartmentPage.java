package Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class ApartmentPage {
    protected static WebDriver driver;
    protected WebDriverWait wait;
    public JavascriptExecutor js;
    private final By clickforApartment = By.xpath("(//div[contains(@class,'dmzfgqv atm_5sauks_glywfm dir dir-ltr')])//div[@class='c4mnd7m atm_9s_11p5wf0 atm_dz_1osqo2v dir dir-ltr']");

    public ApartmentPage(WebDriver driver) {
        ApartmentPage.driver = driver;
        //this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.js = (JavascriptExecutor) driver;
    }


    public BookingPageNextTab clickselectApartment() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(180));
        wait.until(ExpectedConditions.elementToBeClickable(clickforApartment));
        List<WebElement> elements = driver.findElements(clickforApartment);
        //List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(clickforApartment));
        if (!elements.isEmpty()) {
            WebElement firstResult = elements.get(0);
            wait.until(ExpectedConditions.elementToBeClickable(firstResult));
               /* for (int i = 0; i < 4; i++) {
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("window.scrollBy(0, 800);");

                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }*/

            firstResult.click();

        } else {
            System.out.println("No listings found.");
        }
        return new BookingPageNextTab(driver);
    }
    /**
     * Switches to the most recently opened browser tab.
     */
    public void switchToNewTab() {
        String currentWindow = driver.getWindowHandle();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(currentWindow)) {
                driver.switchTo().window(windowHandle);

                //driver.close();
                break;
            }
        }
        //return new BookingPageNextTab(driver);
        // Switch back to the original tab
        //driver.switchTo().window(currentWindow);
    }


}
