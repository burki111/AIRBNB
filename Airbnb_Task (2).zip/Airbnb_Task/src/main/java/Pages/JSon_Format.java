package Pages;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.annotations.SerializedName;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.*;
import java.time.Duration;
import com.google.gson.GsonBuilder;

public class JSon_Format {
    private static String filepathh;
    protected static WebDriver driver;

    public JSon_Format(String filepathh) {
        JSon_Format.filepathh = filepathh;
    }

    public JSon_Format(WebDriver driver) {
        JSon_Format.driver = driver;
    }

    // Write data in JSON format
    public void writeData(ApartmentDetails apartmentDetails) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepathh))) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String jsonData = gson.toJson(apartmentDetails);  // Serialize to JSON
            writer.write(jsonData);
            System.out.println("Data written to JSON: " + jsonData);
        } catch (IOException e) {
            System.out.println("Error");
        }
    }

    // Read data from JSON file
    public ApartmentDetails readData() {
        try (FileReader reader = new FileReader(filepathh)) {
            Gson gson = new Gson();
            return gson.fromJson(reader, ApartmentDetails.class);  // Deserialize from JSON
        } catch (IOException e) {
            System.out.println("Error");
            return null;
        }
    }

    // This method will gather data from the web page and return as an ApartmentDetails object
    public ApartmentDetails gatherDataFromPage() {
        String placeName = getWebElementText(By.xpath("//div[@class='_t0tx82']//h1"));
        String rent = getWebElementText(By.cssSelector("[data-plugin-in-point-id='BOOK_IT_SIDEBAR']"));
        String description = getWebElementText(By.cssSelector("section div.o1kjrihn"));
        String heading = getWebElementText(By.cssSelector("[data-plugin-in-point-id='HOST_OVERVIEW_DEFAULT']"));
        String highlights = getWebElementText(By.cssSelector("[data-plugin-in-point-id='HIGHLIGHTS_DEFAULT']"));
        String defaultDescription = getWebElementText(By.cssSelector("[data-plugin-in-point-id='DESCRIPTION_DEFAULT']"));
        String amenities = getWebElementText(By.cssSelector("[data-plugin-in-point-id='AMENITIES_DEFAULT']"));

        return new ApartmentDetails(placeName, rent, description, heading, highlights, defaultDescription, amenities);
    }

    public static String getWebElementText(By by) {
        return driver.findElement(by).getText();
    }

    public class ApartmentDetails {
        @JsonProperty("PlaceName")
        @SerializedName("PlaceName")
        private final String placeName;
        @SerializedName("Rent")
        private final  String rent;
        @SerializedName("Description")
        private final  String description;
        @SerializedName("Heading")
        private final String heading;
        @SerializedName("Highlights")
        private final  String highlights;
        @SerializedName("DefaultDescription")
        private final  String defaultDescription;
        @SerializedName("Amenities")
        private final  String amenities;

        // Constructors, getters, and setters
        public  ApartmentDetails(String placeName, String rent, String description, String heading, String highlights, String defaultDescription, String amenities) {
            this.placeName = placeName;
            this.rent = rent;
            this.description = description;
            this.heading = heading;
            this.highlights = highlights;
            this.defaultDescription = defaultDescription;
            this.amenities = amenities;
        }

        public String getPlaceName() {
            return placeName;
        }

        public String getRent() {
            return rent;
        }

        public String getDescription() {
            return description;
        }

        public String getHeading() {
            return heading;
        }

        public String getHighlights() {
            return highlights;
        }

        public String getDefaultDescription() {
            return defaultDescription;
        }

        public String getAmenities() {
            return amenities;
        }
    }


}
