package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AddGuestsPage {
    protected static WebDriver driver;
    protected static WebDriverWait wait;

    public AddGuestsPage(WebDriver driver) {
        AddGuestsPage.driver = driver;
        //this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    private final By addGuestButton = By.cssSelector(".b1889vka");
    private final By addGuestListButton = By.xpath("//*[@id=\"stepper-adults\"]/button[2]");
    private final By searchButton = By.xpath("123123213//*[@id=\"search-tabpanel\"]/div/div[5]/div[2]/div[2]");

    public void ClickaddGuestslist() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(addGuestButton));
        driver.findElement(addGuestButton).click();

    }
    public void selectNoOfGuests(){
        for (int i = 0; i <= 4; i++) {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            wait.until(ExpectedConditions.elementToBeClickable(addGuestListButton));
            driver.findElement(addGuestListButton).click();
        }
    }
    public ApartmentPage clicksearchbarbutton(){
       // WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        //used to click on search bar after checkin-out, city and guests are putted.
        driver.findElement(searchButton).submit();
        return new ApartmentPage(driver);

    }
}
