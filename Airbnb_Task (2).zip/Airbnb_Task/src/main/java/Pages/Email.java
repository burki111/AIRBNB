package Pages;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import javax.imageio.ImageIO;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Properties;

import static org.bouncycastle.cert.DeltaCertificateTool.subject;

public class Email {
    private static WebDriver driver;


    public Email (WebDriver driver) {
        Email.driver = driver;
    }

    public static void sendEmailWithExtentReport(String host, String port, final String username, final String password,
                                                 String toAddress, String subject, String message, String attachFile) {
        Properties properties = new Properties();

        // SMTP configuration for SSL/TLS for authentication
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Authenticator auth = new Authenticator() {

            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        };

        Session session = Session.getInstance(properties, auth);

        try {
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(username));
            msg.setRecipient(Message.RecipientType.TO, new InternetAddress(toAddress));
            msg.setSubject(subject);

            // Add message body and attachment
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText(message);
            // Attach extent report
            MimeBodyPart attachPart = new MimeBodyPart();
            if (new File(attachFile).exists()) {
                attachPart.attachFile(attachFile);
            } else {
                System.err.println("Attachment file not found: " + attachFile);
                throw new FileNotFoundException("Attachment file not found: " + attachFile);
            }

            // Attach screenshot
            /*MimeBodyPart screenshotPart = new MimeBodyPart();
            if (new File(screenshot).exists()) {
                screenshotPart.attachFile(screenshot);
            } else {
                System.err.println("Screenshot file not found: " + screenshot);
                throw new FileNotFoundException("Screenshot file not found: " + screenshot);
            }

             */

            // Combine all parts into a multipart message
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachPart);
            // multipart.addBodyPart(screenshotPart);
            msg.setContent(multipart);

            // Send the email
            Transport.send(msg);

            System.out.println("\nEmail sent successfully with attachment.");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
