package Pages;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.jsonSchema.JsonSchema;
import com.fasterxml.jackson.module.jsonSchema.JsonSchemaGenerator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Json_Schema {
    private static final String SCHEMA_PATH = "testDataSchema.json";
    public static void Schema() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JsonSchemaGenerator schemaGen = new JsonSchemaGenerator(mapper);
        JsonSchema schema = schemaGen.generateSchema(JSon_Format.ApartmentDetails.class);
        String schemaAsJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(schema);

        /* Alternate: try (FileWriter file = new FileWriter("SCHEMA_PATH")) {
            file.write(schemaAsJson);
            System.out.println("JSON Schema saved to schema.json");
        } catch (IOException e) {
            e.printStackTrace();

 */

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SCHEMA_PATH))) {
            writer.write(schemaAsJson);
            System.out.println("JSON Schema saved to schema.json");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Step 4: Print the JSON Schema
        System.out.println("Generated JSON Schema:");
        System.out.println(schemaAsJson);

    }
}


