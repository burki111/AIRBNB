package Pages;

import io.github.bonigarcia.wdm.webdriver.WebDriverBrowser;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Objects;

public class SearchPage {
    protected static WebDriver driver;
    public WebDriverWait webDriverWait;
    public static JavascriptExecutor js;
    private final By searchBox = By.cssSelector("#search-tabpanel > div > div.qam9yc8.atm_am_iqcgjs.atm_jb_idpfg4.atm_am_j1sv9b__1v156lz.dir.dir-ltr > div.i1iy0ljo.atm_mk_h2mmj6.atm_h_1h6ojuz.atm_9s_1txwivl.atm_am_qk3dho.atm_gi_1n1ank9.atm_jb_idpfg4.dir.dir-ltr > label");

    public SearchPage(WebDriver driver) {
        SearchPage.driver = driver;
        webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor)driver;
    }

    public void enterDestination(String destination) {
        waitForPageToLoad();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(searchBox));
        driver.findElement(searchBox).sendKeys(destination);
    }
    public void waitForPageToLoad(){
        try {
            webDriverWait.until(driver -> Objects.equals(js
                    .executeScript("return document.readyState"), "complete"));

            System.out.println("Page is fully loaded.");
        } catch (TimeoutException e) {
            System.out.println("Page load timed out.");
        }
    }

}

