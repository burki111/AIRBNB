package Pages;

import dev.failsafe.internal.util.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.time.Duration;

import static Pages.AddGuestsPage.wait;

public class CheckInPage {
    protected static WebDriver driver;
    private final By checkInButton = By.cssSelector(".b1sse431");
    private final By checkInDay = By.xpath("/html/body/div[5]/div/div/div[1]/div/div[3]/div[2]/div/div/div/header/div/div[2]/div[2]/div/div/div/form/div[2]/div/div[3]/div[2]/div/div/div/div/div/div/div/div[2]/div[1]/div/div[1]/div[4]/div/div/div[2]/button[36]");

    public CheckInPage(WebDriver driver) {
        CheckInPage.driver = driver;
    }

    public void clickOnCheckinBar() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(checkInButton));
        driver.findElement(checkInButton).click();
    }

    public void selectCheckInDay() {
        WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait2.until(ExpectedConditions.elementToBeClickable(checkInDay));
        driver.findElement(checkInDay).click();

        //WebElement checkInElement = driver.findElement(checkInDay);
        // checkInElement.click();

        //String actualCheckInDate = checkInElement.getText();
        //if (!actualCheckInDate.equals(expectedCheckInDate)) {
        //  System.out.println("Error: Wrong check-in date selected.");
        //throw new AssertionError("Test failed: Wrong check-in date selected.");
    }
    // checkInElement.click();
}

