package Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BookingPageNextTab {
    protected static WebDriver driver;

    public BookingPageNextTab(WebDriver driver) {
        BookingPageNextTab.driver = driver;
    }

    /**
     * Close the pop-up if present.
     */
    public void closePopUp() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        try {
            WebElement modal = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[data-testid='modal-container']")));

            WebElement closeButton = modal.findElement(By.xpath(".//button[@aria-label='Close']"));
            closeButton.click();

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0, 800);");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            System.out.println("Error closing popup: " + e.getMessage());
        }
    }
    }

